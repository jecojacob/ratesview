﻿namespace WCC.Rates.RatesView.Core;

public class Class1
{

}
