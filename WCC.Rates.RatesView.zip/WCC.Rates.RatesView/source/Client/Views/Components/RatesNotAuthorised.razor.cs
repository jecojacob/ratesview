namespace WCC.Rates.RatesView.Client.Views.Components
{
		using Microsoft.AspNetCore.Components;
		using Microsoft.FluentUI.AspNetCore.Components;
		using System;
		using System.Collections.Generic;
		using System.Linq;
		using System.Threading.Tasks;

		public partial class RatesNotAuthorised  
	{
		FluentButton RatesViewLogin;
	 public void ButtonClick()
		{
			//RatesViewLogin.Loading = true;
		 Console.WriteLine("ButtonClick");
		//	StateHasChanged();
	 }
				 	 
		}
}
 
