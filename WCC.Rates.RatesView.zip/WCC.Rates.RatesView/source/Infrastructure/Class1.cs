﻿namespace WCC.Rates.RatesView.Infrastructure;

public class Class1
{

}
